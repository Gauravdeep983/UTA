Solution for homework 1 is provided in "Homework-01.xlsx" under each sheet named after the question number (Q1, Q2,...,Q5)

Q5 includes an image as solution (also included in the ZIP file)

~ ~
Gauravdeep Singh
1001827248
