package Homework5;

public interface Problem5ServerData {
	public double getCart();
}
